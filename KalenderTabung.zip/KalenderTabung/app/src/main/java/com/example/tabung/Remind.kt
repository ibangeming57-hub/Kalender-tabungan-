package com.example.tabung

import android.app.*
import android.content.*
import android.os.Build
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class Remind : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = c.getSharedPreferences("w", Context.MODE_PRIVATE)
        if (i.action == Intent.ACTION_BOOT_COMPLETED) { plan(c, p.getBoolean("on", false), p.getInt("h", 20), p.getInt("m", 0)); return }
        val j = JSONObject(p.getString("j", "{}")!!)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (j.optBoolean("d") && j.optString("dt") == today) return
        val o = j.optJSONArray("o"); val dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
        if (o != null && (0 until o.length()).any { o.getInt(it) == dow }) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("r", "Pengingat nabung", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(c, 2, Intent(c, MainActivity::class.java).putExtra("fill", true), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, "r") else Notification.Builder(c)
        nm.notify(1, b.setSmallIcon(android.R.drawable.ic_menu_my_calendar).setContentTitle("Waktunya nabung 🐷").setContentText("Kamu belum nabung hari ini. Ketuk untuk isi.").setContentIntent(pi).setAutoCancel(true).build())
    }

    companion object {
        fun plan(c: Context, on: Boolean, h: Int, m: Int) {
            c.getSharedPreferences("w", Context.MODE_PRIVATE).edit().putBoolean("on", on).putInt("h", h).putInt("m", m).apply()
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(c, 3, Intent(c, Remind::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            am.cancel(pi)
            if (!on) return
            val t = Calendar.getInstance()
            t.set(Calendar.HOUR_OF_DAY, h); t.set(Calendar.MINUTE, m); t.set(Calendar.SECOND, 0)
            if (t.timeInMillis <= System.currentTimeMillis()) t.add(Calendar.DAY_OF_MONTH, 1)
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, t.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        }
    }
}
