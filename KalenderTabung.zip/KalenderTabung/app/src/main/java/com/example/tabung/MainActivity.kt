package com.example.tabung

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var wv: WebView
    private var cb: android.webkit.ValueCallback<Array<android.net.Uri>>? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onShowFileChooser(w: WebView?, c: android.webkit.ValueCallback<Array<android.net.Uri>>?, p: android.webkit.WebChromeClient.FileChooserParams?): Boolean {
                cb?.onReceiveValue(null); cb = c
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 7)
                return true
            }
        }
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) { fill(intent) }
        }
        setContentView(wv)
        wv.loadUrl("file:///android_asset/index.html")
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        if (rq == 7) { cb?.onReceiveValue(if (rs == RESULT_OK && d?.data != null) arrayOf(d!!.data!!) else null); cb = null }
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); intent = i; fill(i) }

    // Tombol "Isi hari ini" di widget membuka sheet nominal untuk hari ini
    private fun fill(i: Intent) { if (i.getBooleanExtra("fill", false)) wv.evaluateJavascript("am(TK)", null) }

    inner class Bridge {
        @JavascriptInterface
        fun remind(on: Boolean, h: Int, m: Int) {
            Remind.plan(this@MainActivity, on, h, m)
            if (on && Build.VERSION.SDK_INT >= 33) runOnUiThread { requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 9) }
        }

        @JavascriptInterface
        fun sync(j: String) {
            getSharedPreferences("w", MODE_PRIVATE).edit().putString("j", j).apply()
            val m = AppWidgetManager.getInstance(this@MainActivity)
            val ids = m.getAppWidgetIds(ComponentName(this@MainActivity, TabungWidget::class.java))
            TabungWidget.draw(this@MainActivity, m, ids)
        }
    }
}
